export class User {
  customerFName: string;
  customerLName: string;
  city: string;
  province: string;
  createdDate: string;
  lastUpdate: string;
}
