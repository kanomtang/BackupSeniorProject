/**
 * Created by pariy on 9/3/2017.
 */
export class Lot {
  productID: string;
  // lotID: string;
  qrCode: string;
  amount: number;
  expiryDate: string;
}
