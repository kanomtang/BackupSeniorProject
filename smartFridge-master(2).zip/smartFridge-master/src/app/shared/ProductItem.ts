import {Lot} from './Lot';
export class ProductItem {
  CreatedDate: string;
  InUse: boolean;
  Price: number;
  LastUpdate: string;
  ProductName: string;
}
